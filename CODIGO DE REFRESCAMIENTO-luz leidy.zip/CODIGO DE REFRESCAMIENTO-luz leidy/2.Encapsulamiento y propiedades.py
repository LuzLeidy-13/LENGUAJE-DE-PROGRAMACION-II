class Producto:
    def __init__(self, nombre, precio):
        self._nombre = nombre
        self.set_precio(precio)

  
    def get_precio(self):
        return self._precio

    def set_precio(self, nuevo_precio):
        if nuevo_precio < 0:
            raise ValueError("El precio no puede ser negativo.")
        self._precio = nuevo_precio


    def aplicar_descuento(self, porcentaje):
        if porcentaje < 0 or porcentaje > 100:
            print(" Descuento inválido.")
            return
        
        descuento = self._precio * (porcentaje / 100)
        self._precio -= descuento
        print(f" Se aplicó un descuento del {porcentaje}%. Nuevo precio: {self._precio:.2f}")


    def mostrar_info(self):
        print(f"Producto: {self._nombre}  Precio: {self._precio}")



producto1 = Producto("Camisa", 80)
producto2 = Producto("Pantalón", 120)

producto1.mostrar_info()
producto2.mostrar_info()


producto1.aplicar_descuento(15)
producto2.aplicar_descuento(150)

try:
    producto1.set_precio(-50)
except ValueError as error:
    print("Error:", error)
