class Vehiculo:
    def acelerar(self):
        print("acelerando")

class Volador:
    def volar(self):
        print("volando")

class Avion(Vehiculo, Volador):
    def despegar(self):
        print("El avion esta despegando")

avion = Avion()
avion.acelerar()
avion.volar()
avion.despegar()

