import tkinter as tk
import time

class TorresDeHanoi:
    def __init__(self, num_discos, torres):
        self.num_discos = num_discos
        self.torres = [[] for _ in range(3)]
        self.movimientos = 0

        # Inicializar la primera torre con los discos (mayor a menor)
        for i in range(num_discos, 0, -1):
            self.torres[0].append(i)

        # --- Interfaz gráfica ---
        self.ventana = tk.Tk()
        self.ventana.title("🧩 Torres de Hanoi - Modo Interactivo")

        # Crear el lienzo (canvas)
        self.canvas = tk.Canvas(self.ventana, width=600, height=400, bg="white")
        self.canvas.pack(pady=10)

        # Parámetros gráficos
        self.base_y = 350
        self.espaciado = 200
        self.altura_disco = 20
        self.ancho_torre = 10

        # Etiqueta de estado
        self.lbl_estado = tk.Label(self.ventana, text="Estado inicial", font=("Arial", 12))
        self.lbl_estado.pack(pady=5)

        # Frame de controles
        frame_controles = tk.Frame(self.ventana)
        frame_controles.pack(pady=10)

        tk.Label(frame_controles, text="Origen (1-3):").grid(row=0, column=0, padx=5)
        self.origen_var = tk.StringVar()
        tk.Entry(frame_controles, textvariable=self.origen_var, width=5).grid(row=0, column=1, padx=5)

        tk.Label(frame_controles, text="Destino (1-3):").grid(row=0, column=2, padx=5)
        self.destino_var = tk.StringVar()
        tk.Entry(frame_controles, textvariable=self.destino_var, width=5).grid(row=0, column=3, padx=5)

        tk.Button(frame_controles, text="Mover", command=self.mover_interactivo, bg="lightgray").grid(row=0, column=4, padx=10)

        # Dibujar elementos iniciales
        self.dibujar_torres()
        self.dibujar_discos()
        self.ventana.mainloop()

    def dibujar_torres(self):
        """Dibuja las 3 torres"""
        self.canvas.delete("torres")
        for i in range(3):
            x = 100 + i * self.espaciado
            self.canvas.create_rectangle(x - self.ancho_torre // 2, 150,
                                         x + self.ancho_torre // 2, self.base_y,
                                         fill="gray40", tags="torres")
        self.canvas.create_rectangle(50, self.base_y, 550, self.base_y + 10, fill="black", tags="torres")

    def dibujar_discos(self):
        """Dibuja los discos en las torres"""
        self.canvas.delete("discos")
        colores = ["red", "orange", "yellow", "green", "blue", "purple", "pink", "cyan", "lime"]
        for t, torre in enumerate(self.torres):
            x_centro = 100 + t * self.espaciado
            for nivel, disco in enumerate(torre):
                ancho = disco * 15
                y = self.base_y - nivel * self.altura_disco
                self.canvas.create_rectangle(x_centro - ancho // 2, y - self.altura_disco,
                                             x_centro + ancho // 2, y,
                                             fill=colores[disco % len(colores)],
                                             tags="discos")
        self.ventana.update()

    def mover_disco(self, origen, destino):
        """Mueve un disco entre torres con validación"""
        if not self.torres[origen]:
            self.lbl_estado.config(text=f" Torre {origen + 1} vacía", fg="red")
            return
        disco = self.torres[origen][-1]
        if self.torres[destino] and disco > self.torres[destino][-1]:
            self.lbl_estado.config(text=f" No se puede colocar disco {disco} sobre uno más pequeño.", fg="red")
            return

        disco_movido = self.torres[origen].pop()
        self.torres[destino].append(disco_movido)
        self.movimientos += 1

        # Actualizar visualmente
        self.lbl_estado.config(text=f"📦 Movimiento {self.movimientos}: Torre {origen + 1} → Torre {destino + 1}", fg="black")
        self.dibujar_discos()

        # Verificar si terminó
        if len(self.torres[2]) == self.num_discos:
            self.lbl_estado.config(text=f"🎉 ¡Felicidades! Completaste el juego en {self.movimientos} movimientos.", fg="green")

    def mover_interactivo(self):
        """Lee los valores del usuario y realiza el movimiento"""
        try:
            origen = int(self.origen_var.get()) - 1
            destino = int(self.destino_var.get()) - 1
            if origen not in [0, 1, 2] or destino not in [0, 1, 2]:
                raise ValueError
            self.mover_disco(origen, destino)
        except ValueError:
            self.lbl_estado.config(text="⚠️ Ingrese torres válidas (1, 2 o 3).", fg="red")


# Ejecutar aplicación
if __name__ == "__main__":
    hanoi = TorresDeHanoi(4)
