class CuentaBancaria:
    def __init__(self, titular, saldo):
        self.__titular = titular
        self.__saldo = max(0, saldo)
        
    def get_titular(self):
        return self.__titular
    
    def get_saldo(self):
        return self.__saldo
    
    def set_titular(self, nuevo_titular):
        self.__titular = nuevo_titular

    def set_saldo(self, nuevo_saldo):
        if nuevo_saldo >=0:
            self.__saldo = nuevo_saldo
        else:
            print("Error: Ingrese un saldo positivo.")

    def mostrar_datos(self):
        print(f"Titular: {self.__titular} - Saldo: ${self.__saldo}")

cuenta = CuentaBancaria("Ana Pérez", 5000)
cuenta.mostrar_datos()
cuenta.set_saldo(7000)
cuenta.mostrar_datos()
cuenta.set_saldo(-100)

    
