class Producto:
    def __init__(self, nombre, precio):
        self.__nombre = nombre
        self.__precio = max(0,precio) 
    
    @property
    def nombre(self):
        return self.__nombre

    @property
    def precio(self):
        return self.__precio
    
    @nombre.setter
    def nombre(self, valor):
        self.__nombre = valor
    
    @precio.setter
    def precio(self, valor):
        if valor >= 0:
            self.__precio = valor    
        else:
            print("Error: El precio no puede ser negativo ni cero")
            
    def mostrar_producto(self):
        print(f"Producto: {self.nombre} - Precio: {self.precio}")

p1 = Producto("Laptop", 2500)
p1.mostrar_producto()

p1.precio = 3000
p1.mostrar_producto()      

p1.precio = -50            

