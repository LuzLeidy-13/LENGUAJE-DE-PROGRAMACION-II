import tkinter as tk
import time

class TorresDeHanoi:
    def __init__(self, num_discos):
        self.num_discos = num_discos
        self.torres = [[] for _ in range(3)]
        self.movimientos = 0

        # Inicializar la primera torre con los discos
        for i in range(num_discos, 0, -1):
            self.torres[0].append(i)

        # --- Interfaz gráfica ---
        self.ventana = tk.Tk()
        self.ventana.title(" Torres de Hanoi - Visualización Gráfica")

        # Crear el lienzo (canvas)
        self.canvas = tk.Canvas(self.ventana, width=600, height=400, bg="white")
        self.canvas.pack(pady=10)

        # Parámetros gráficos
        self.base_y = 350
        self.espaciado = 200
        self.altura_disco = 20
        self.ancho_torre = 10

        # Etiqueta de estado
        self.lbl_estado = tk.Label(self.ventana, text="Estado inicial", font=("Arial", 12))
        self.lbl_estado.pack(pady=5)

        # Dibujar elementos iniciales
        self.dibujar_torres()
        self.dibujar_discos()
        self.ventana.update()

    def dibujar_torres(self):
        self.canvas.delete("torres")
        for i in range(3):
            x = 100 + i * self.espaciado
            self.canvas.create_rectangle(x - self.ancho_torre // 2, 150,
                                         x + self.ancho_torre // 2, self.base_y,
                                         fill="gray40", tags="torres")
        # para la Base
        self.canvas.create_rectangle(50, self.base_y, 550, self.base_y + 10, fill="black", tags="torres")

    def dibujar_discos(self):
        """Dibuja los discos en las torres"""
        self.canvas.delete("discos")
        colores = ["red", "orange", "yellow", "green", "blue", "purple", "pink"]
        for t, torre in enumerate(self.torres):
            x_centro = 100 + t * self.espaciado
            for nivel, disco in enumerate(torre):
                ancho = disco * 15
                y = self.base_y - nivel * self.altura_disco
                self.canvas.create_rectangle(x_centro - ancho // 2, y - self.altura_disco,
                                             x_centro + ancho // 2, y,
                                             fill=colores[disco % len(colores)],
                                             tags="discos")
        self.ventana.update()
        time.sleep(0.9)

    def mover_disco(self, origen, destino):
        """Mueve un disco entre torres con validación"""
        if not self.torres[origen]:
            raise ValueError(f"Torre {origen} vacía")
        disco = self.torres[origen][-1]

        if self.torres[destino] and disco > self.torres[destino][-1]:
            raise ValueError(f"Disco {disco} no puede ir sobre {self.torres[destino][-1]}")

        disco_movido = self.torres[origen].pop()
        self.torres[destino].append(disco_movido)
        self.movimientos += 1

        # Actualizar visualmente
        self.lbl_estado.config(text=f"Movimiento {self.movimientos}: Torre {origen} → Torre {destino}")
        self.dibujar_discos()
        return disco_movido

    def resolver(self, n, origen, destino, auxiliar):
        if n == 1:
            self.mover_disco(origen, destino)
            return
        self.resolver(n - 1, origen, auxiliar, destino)
        self.mover_disco(origen, destino)
        self.resolver(n - 1, auxiliar, destino, origen)

    def mostrar_estado(self):
        for i, torre in enumerate(self.torres):
            print(f"Torre {i}: {torre}")

    def mostrar_estado_grafico(self):
        """(No se usa en Tkinter, pero se conserva el método por compatibilidad)"""
        self.dibujar_discos()

    def ejecutar(self):
        """Ejecuta la resolución completa con animación"""
        print("Estado inicial:")
        self.mostrar_estado()
        print("\n🧩 Iniciando resolución...\n")
        self.resolver(self.num_discos, 0, 2, 1)
        print("\n PROBLEMA RESUELTO!")
        print(f"Total de movimientos: {self.movimientos}")
        print(f"Movimientos teóricos mínimos: {2 ** self.num_discos - 1}")
        self.lbl_estado.config(
            text=f" Completado en {self.movimientos} movimientos (mínimo: {2 ** self.num_discos - 1})"
        )
        self.ventana.mainloop()

if __name__ == "__main__":
   
    hanoi = TorresDeHanoi(4)
    hanoi.ejecutar()
